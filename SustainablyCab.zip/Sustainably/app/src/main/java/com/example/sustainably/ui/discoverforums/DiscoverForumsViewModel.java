package com.example.sustainably.ui.discoverforums;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DiscoverForumsViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public DiscoverForumsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Discover Forums fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}