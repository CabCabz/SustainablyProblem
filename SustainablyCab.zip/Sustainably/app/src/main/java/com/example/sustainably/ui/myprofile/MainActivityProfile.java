package com.example.sustainably.ui.myprofile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.example.sustainably.R;
import com.google.android.material.tabs.TabLayout;

public class MainActivityProfile extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_myprofile);

        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        // Add Fragment Here

        adapter.AddFragment(new PublicBookmarkFragment(), "Public Bookmarks");
        adapter.AddFragment(new LatestPostsFragment(), "Latest Posts");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_outline_bookmarks_24);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_outline_textsms_24);
    }
}
