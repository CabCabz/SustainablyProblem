package com.example.sustainably.ui.myprofile;

public class BookmarkModel {

    private String Title;
    private int Photo;

    public BookmarkModel() {
    }

    public BookmarkModel(String title, int photo) {
        Title = title;
        Photo = photo;
    }

    // Getter
    public String getTitle() {
        return Title;
    }
    public int getPhoto() {
        return Photo;
    }
    // Setter
    public void setTitle(String title) {
        Title = title;
    }

    public void setPhoto(int photo) {
        Photo = photo;
    }
}