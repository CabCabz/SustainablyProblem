package com.example.sustainably.ui.myprofile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sustainably.R;

import java.util.ArrayList;
import java.util.List;

public class PublicBookmarkFragment extends Fragment {

    View v;
    private RecyclerView myrecyclerview;
    private List<BookmarkModel> lstBookmarkModel;

    public PublicBookmarkFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.public_bookmarks_fragment, container, false);
        myrecyclerview = (RecyclerView) v.findViewById(R.id.bookmarks_recyclerview);
        RecyclerViewAdapter recyclerAdapter = new RecyclerViewAdapter(getContext(), lstBookmarkModel);
        myrecyclerview.setLayoutManager(new GridLayoutManager(getContext(), 2));
        myrecyclerview.setAdapter(recyclerAdapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        lstBookmarkModel = new ArrayList<>();
        lstBookmarkModel.add(new BookmarkModel("Salad", R.drawable.annapelzer));
        lstBookmarkModel.add(new BookmarkModel("Pasta", R.drawable.brookelark_1));
        lstBookmarkModel.add(new BookmarkModel("Fruit Salad", R.drawable.brookelark_2));
        lstBookmarkModel.add(new BookmarkModel("Smoothies with fruit", R.drawable.brookelark_3));
        lstBookmarkModel.add(new BookmarkModel("Soup", R.drawable.cala));
        lstBookmarkModel.add(new BookmarkModel("Lobster Salad", R.drawable.davide_cantelli));
        lstBookmarkModel.add(new BookmarkModel("Breakfast Toast with Berries", R.drawable.joseph_gonzales));

    }
}